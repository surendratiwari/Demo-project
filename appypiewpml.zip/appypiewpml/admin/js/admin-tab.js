/* executed for admin tap bar language translator 2016 */
jQuery(document).ready(
function($){
		$(".lsb_style_wrap_class li").click(function(){
        $(".qtranxs-lang-switch-wrap li").eq($(".lsb_style_wrap_class li").index(this)).click()});
		$(".lsb_style_wrap_class").on("click","li", function(){
        $(this).addClass("active1").siblings().removeClass("active1");
     });
});

function openlang(evt, lang) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(lang).style.display = "block";
    evt.currentTarget.className += " active";
}