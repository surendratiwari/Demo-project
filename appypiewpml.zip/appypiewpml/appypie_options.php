<?php // encoding: utf-8
if ( !defined( 'ABSPATH' ) ) exit;
/* There is no need to edit anything here! */
define('QTX_STRING',	1);
define('QTX_BOOLEAN',	2);
define('QTX_INTEGER',	3);
define('QTX_URL',	4);
define('QTX_LANGUAGE',	5);
define('QTX_ARRAY',	6);
define('QTX_BOOLEAN_SET',	7);
define('QTX_TEXT',	8);//multi-line string

define('QTX_URL_QUERY'  , 1);// query: domain.com?lang=en
define('QTX_URL_PATH'   , 2);// pre path: domain.com/en
define('QTX_URL_DOMAIN' , 3);// pre domain: en.domain.com
define('QTX_URL_DOMAINS', 4);// domain per language

define('QTX_DATE_WP', 0);// default
// strftime usage (backward compability)
define('QTX_STRFTIME_OVERRIDE', 1);
define('QTX_DATE_OVERRIDE', 2);
define('QTX_DATE', 3);// old default
define('QTX_STRFTIME', 4);

define('QTX_FILTER_OPTIONS_ALL', 0);
define('QTX_FILTER_OPTIONS_LIST', 1);
define('QTX_FILTER_OPTIONS_DEFAULT','blogname blogdescription widget_%');

define('QTX_EX_DATE_FORMATS_DEFAULT','\'U\'');

define('QTX_EDITOR_MODE_LSB', 0);//Language Switching Buttons
define('QTX_EDITOR_MODE_RAW', 1);
define('QTX_EDITOR_MODE_SINGLGE', 2);

define('QTX_HIGHLIGHT_MODE_NONE', 0);
define('QTX_HIGHLIGHT_MODE_BORDER_LEFT', 1);
define('QTX_HIGHLIGHT_MODE_BORDER', 2);
define('QTX_HIGHLIGHT_MODE_LEFT_SHADOW', 3);
define('QTX_HIGHLIGHT_MODE_OUTLINE', 4);
define('QTX_HIGHLIGHT_MODE_CUSTOM_CSS', 9);

define('QTX_COOKIE_NAME_FRONT','qtrans_front_language');
define('QTX_COOKIE_NAME_ADMIN','qtrans_admin_language');

define('QTX_IGNORE_FILE_TYPES','gif,jpg,jpeg,png,svg,pdf,swf,tif,rar,zip,7z,mpg,divx,mpeg,avi,css,js,mp3,mp4,apk');


global $q_config;
global $appypie_options;


/**
 * array of default option values
 * other plugins and themes should not use global variables directly, they are subject to change at any time.
 */
function qtranxf_set_default_options(&$ops)
{
	$ops = array();

	//options processed in a standardized way
	$ops['front'] = array();

	$ops['front']['int']=array(
		'url_mode' => QTX_URL_PATH,// sets default url mode
		'use_strftime' => QTX_DATE,// strftime usage (backward compability)
		'filter_options_mode' => QTX_FILTER_OPTIONS_ALL,
		'language_name_case' => 0 //Camel Case
	);

	$ops['front']['bool']=array(
		'detect_browser_language' => true,// enables browser language detection
		'hide_untranslated' => false,// hide pages without content
		'show_displayed_language_prefix' => true,
		'show_alternative_content' => false,
		'hide_default_language' => true,// hide language tag for default language in urls
		'use_secure_cookie' => false,
		'header_css_on' => true,
	);

	//single line options
	$ops['front']['str']=array(
	);

	//multi-line options
	$ops['front']['text']=array(
		'header_css' => 'qtranxf_front_header_css_default',
	);
	$ops['front']['array']=array(
		//'term_name'// uniquely special treatment
		'text_field_filters' => array(),
		'front_config' => array(),
	);

	// store other default values of specially handled options
	$ops['default_value']=array(
		'default_language' => null,//string
		'enabled_languages' => null,//array
		'qtrans_compatibility' => false,//enables compatibility with former qtrans_* functions
		'disable_client_cookies' => false,//bool
		'flag_location' => null,//string
		'filter_options' => QTX_FILTER_OPTIONS_DEFAULT,//array
		'ignore_file_types' => QTX_IGNORE_FILE_TYPES,//array
		'domains' => null,//array
	);

	$ops['languages']=array(
		'language_name' => 'appypie_language_names',
		'locale' => 'appypie_locales',
		'locale_html' => 'appypie_locales_html',
		'not_available' => 'appypie_na_messages',
		'date_format' => 'appypie_date_formats',
		'time_format' => 'appypie_time_formats',
		'flag' => 'appypie_flags',
	);

	/**
	 * A chance to add additional options
	*/
	$ops = apply_filters('appypie_option_config',$ops);
}

/**
 * Names for languages in the corresponding language, add more if needed
 */
function qtranxf_default_language_name()
{
	//Native Name
	$nnm = array();
	$nnm['de'] = 'Deutsch';
	$nnm['en'] = 'English';
	$nnm['zh'] = '中文';// 简体中文
	$nnm['ru'] = 'Русский';
	$nnm['fi'] = 'suomi';
	$nnm['fr'] = 'Français';
	$nnm['nl'] = 'Nederlands';
	$nnm['sv'] = 'Svenska';
	$nnm['it'] = 'Italiano';
	$nnm['ro'] = 'Română';
	$nnm['hu'] = 'Magyar';
	$nnm['ja'] = '日本語';
	$nnm['es'] = 'Español';
	$nnm['vi'] = 'Tiếng Việt';
	$nnm['ar'] = 'العربية';
	$nnm['pt'] = 'Português';
	$nnm['pb'] = 'Português do Brasil';
	$nnm['pl'] = 'Polski';
	$nnm['gl'] = 'galego';
	$nnm['tr'] = 'Turkish';
	$nnm['et'] = 'Eesti';
	$nnm['hr'] = 'Hrvatski';
	$nnm['eu'] = 'Euskera';
	$nnm['el'] = 'Ελληνικά';
	$nnm['ua'] = 'Українська';
	$nnm['cy'] = 'Cymraeg';
	$nnm['ca'] = 'Català';
	$nnm['sk'] = 'Slovenčina';
	$nnm['lt'] = 'Lietuvių';
	return $nnm;
}

/**
 * Locales for languages
 * @since 3.3
 */
function qtranxf_default_locale()
{
	// see locale -a for available locales
	$loc = array();
	$loc['de'] = 'de_DE';
	$loc['en'] = 'en_US';
	$loc['zh'] = 'zh_CN';
	$loc['ru'] = 'ru_RU';
	$loc['fi'] = 'fi';//changed from fi_FI on Nov 10 2016 to match WordPress locale
	$loc['fr'] = 'fr_FR';
	$loc['nl'] = 'nl_NL';
	$loc['sv'] = 'sv_SE';
	$loc['it'] = 'it_IT';
	$loc['ro'] = 'ro_RO';
	$loc['hu'] = 'hu_HU';
	$loc['ja'] = 'ja';
	$loc['es'] = 'es_ES';
	$loc['vi'] = 'vi';
	$loc['ar'] = 'ar';
	$loc['pt'] = 'pt_PT';
	$loc['pb'] = 'pt_BR';
	$loc['pl'] = 'pl_PL';
	$loc['gl'] = 'gl_ES';
	$loc['tr'] = 'tr_TR';
	$loc['et'] = 'et';
	$loc['hr'] = 'hr';
	$loc['eu'] = 'eu';
	$loc['el'] = 'el';
	$loc['ua'] = 'uk';
	$loc['cy'] = 'cy';// not 'cy_GB'
	$loc['ca'] = 'ca';
	$loc['sk'] = 'sk_SK';
	$loc['lt'] = 'lt_LT';
	//$loc['tw'] = 'zh_TW';
	return $loc;
}

/**
 * HTML locales for languages
 * @since 3.4
 */
function qtranxf_default_locale_html(){
	//HTML locales for languages are not provided by default
	$cfg = array();
	return $cfg;
}

/**
 * Language not available messages
 * @since 3.3
 */
add_action( 'wp_enqueue_scripts', 'prefix_add_my_stylesheet' );

/**
 * Enqueue plugin style-file
 */
function prefix_add_my_stylesheet() {
    // Respects SSL, Style.css is relative to the current file
    wp_register_style( 'prefix-style', plugins_url('/css/custom.css', __FILE__) );
    wp_enqueue_style( 'prefix-style' );
}
 
function qtranxf_default_not_available()
{
	$appypie='
    <div id="google_translate_element">
    <script>
	function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: "en", includedLanguages: "ar,da,en,es,fr,nl,ja,pt,ru,zh-CN",
	 locale:"zh",
	 autoDisplay: false},
	"google_translate_element");
     }</script>
 <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit">
 </script></div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script> 

  $(document).ready(function(){ 
  	setTimeout(function(){ 
		var lang = document.location.href.split(".")[0].split("//")[1];
		if(lang == "cn")
         {
          lang = "zh-CN"
         }
		 else if(lang == "de")
         {
          lang = "da"
         }
		//alert(lang );
		jQuery(".goog-te-combo").val(lang);
		fireEvent(jQuery(".goog-te-combo")[0], "change")
		}, 1000);
  });
  // select value
  function fireEvent(el,e){
    if (document.createEventObject){
        //for IE
        var evt = document.createEventObject();
        return el.fireEvent("on"+e,evt)
    }
    else{
        // For other browsers
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent(e, true, true ); 
        return !el.dispatchEvent(evt);
    }
}
</script>';
	//Not Available Message
	$nam = array();
	$nam['de'] = $appypie;//ok
	$nam['en'] = $appypie;//ok
	$nam['zh'] = $appypie;//ok
	$nam['ru'] = $appypie;//ok
	$nam['fi'] = $appypie;
	$nam['fr'] = $appypie;//ok
	$nam['nl'] = $appypie;//ok
	$nam['sv'] = $appypie;
	$nam['it'] = $appypie;
	$nam['ro'] = $appypie;
	$nam['hu'] = $appypie;
	$nam['ja'] = $appypie;//ok
	$nam['es'] = $appypie;//ok
	$nam['vi'] = $appypie;
	$nam['ar'] = $appypie;//ok
	$nam['pt'] = $appypie;//ok
	$nam['pb'] = $appypie;
	$nam['pl'] = $appypie;
	$nam['gl'] = $appypie;
	$nam['tr'] = $appypie;
	$nam['et'] = $appypie;
	$nam['hr'] = $appypie;
	$nam['eu'] = $appypie;
	$nam['el'] = $appypie;
	$nam['ua'] = $appypie;
	$nam['cy'] = $appypie;
	$nam['ca'] = $appypie;
	$nam['sk'] = $appypie;
	$nam['lt'] = $appypie;
	return $nam;
}

/**
 * Date Configuration
 */
function qtranxf_default_date_format()
{
	$dtf = array();
	$dtf['en'] = '%A %B %e%q, %Y';
	$dtf['de'] = '%A, \d\e\r %e. %B %Y';
	$dtf['zh'] = '%x %A';
	$dtf['ru'] = '%A %B %e%q, %Y';
	//$dtf['fi'] = '%e.&m.%C';
	$dtf['fi'] = '%d.%m.%Y';
	$dtf['fr'] = '%A %e %B %Y';
	$dtf['nl'] = '%d/%m/%y';
	$dtf['sv'] = '%Y-%m-%d';
	$dtf['it'] = '%e %B %Y';
	$dtf['ro'] = '%A, %e %B %Y';
	$dtf['hu'] = '%Y %B %e, %A';
	$dtf['ja'] = '%Y年%m月%d日';
	$dtf['es'] = '%d \d\e %B \d\e %Y';
	$dtf['vi'] = '%d/%m/%Y';
	$dtf['ar'] = '%d/%m/%Y';
	$dtf['pt'] = '%A, %e \d\e %B \d\e %Y';
	$dtf['pb'] = '%d \d\e %B \d\e %Y';
	$dtf['pl'] = '%d/%m/%y';
	$dtf['gl'] = '%d \d\e %B \d\e %Y';
	$dtf['tr'] = '%A %B %e%q, %Y';
	$dtf['et'] = '%A %B %e%q, %Y';
	$dtf['hr'] = '%d/%m/%Y';
	$dtf['eu'] = '%Y %B %e, %A';
	$dtf['el'] = '%d/%m/%y';
	$dtf['ua'] = '%A %B %e%q, %Y';
	$dtf['cy'] = '%A %B %e%q, %Y';
	$dtf['ca'] = 'j F, Y';
	$dtf['sk'] = 'j.F Y';
	$dtf['lt'] = '%Y.%m.%d';
	return $dtf;
}

/**
 * Time Configuration
 */
function qtranxf_default_time_format()
{
	$tmf = array();
	$tmf['en'] = '%I:%M %p';
	$tmf['de'] = '%H:%M';
	$tmf['zh'] = '%I:%M%p';
	$tmf['ru'] = '%H:%M';
	$tmf['fi'] = '%H:%M';
	$tmf['fr'] = '%H:%M';
	$tmf['nl'] = '%H:%M';
	$tmf['sv'] = '%H:%M';
	$tmf['it'] = '%H:%M';
	$tmf['ro'] = '%H:%M';
	$tmf['hu'] = '%H:%M';
	$tmf['ja'] = '%H:%M';
	$tmf['es'] = '%H:%M hrs.';
	$tmf['vi'] = '%H:%M';
	$tmf['ar'] = '%H:%M';
	$tmf['pt'] = '%H:%M';
	$tmf['pb'] = '%H:%M hrs.';
	$tmf['pl'] = '%H:%M';
	$tmf['gl'] = '%H:%M hrs.';
	$tmf['tr'] = '%H:%M';
	$tmf['et'] = '%H:%M';
	$tmf['hr'] = '%H:%M';
	$tmf['eu'] = '%H:%M';
	$tmf['el'] = '%H:%M';
	$tmf['ua'] = '%H:%M';
	$tmf['cy'] = '%I:%M %p';
	$tmf['ca'] = 'G:i';
	$tmf['sk'] = 'G:i';
	$tmf['lt'] = '%H:%M';
	return $tmf;
}

/**
 * Flag images configuration
 * Look in /flags/ directory for a huge list of flags for usage
 */
function qtranxf_default_flag()
{
	$flg = array();
	$flg['en'] = 'gb.png';
	$flg['de'] = 'de.png';
	$flg['zh'] = 'cn.png';
	$flg['ru'] = 'ru.png';
	$flg['fi'] = 'fi.png';
	$flg['fr'] = 'fr.png';
	$flg['nl'] = 'nl.png';
	$flg['sv'] = 'se.png';
	$flg['it'] = 'it.png';
	$flg['ro'] = 'ro.png';
	$flg['hu'] = 'hu.png';
	$flg['ja'] = 'jp.png';
	$flg['es'] = 'es.png';
	$flg['vi'] = 'vn.png';
	$flg['ar'] = 'arle.png';
	$flg['pt'] = 'pt.png';
	$flg['pb'] = 'br.png';
	$flg['pl'] = 'pl.png';
	$flg['gl'] = 'galego.png';
	$flg['tr'] = 'tr.png';
	$flg['et'] = 'ee.png';
	$flg['hr'] = 'hr.png';
	$flg['eu'] = 'eu_ES.png';
	$flg['el'] = 'gr.png';
	$flg['ua'] = 'ua.png';
	$flg['cy'] = 'cy_GB.png';
	$flg['ca'] = 'catala.png';
	$flg['sk'] = 'sk.png';
	$flg['lt'] = 'lt.png';
	return $flg;
}

/**
 * Full country names as locales for Windows systems
 */
function qtranxf_default_windows_locale()
{
	//English Name
	$enm = array();
	$enm['aa'] = "Afar";
	$enm['ab'] = "Abkhazian";
	$enm['ae'] = "Avestan";
	$enm['af'] = "Afrikaans";
	$enm['am'] = "Amharic";
	$enm['ar'] = "Arabic";
	$enm['as'] = "Assamese";
	$enm['ay'] = "Aymara";
	$enm['az'] = "Azerbaijani";
	$enm['ba'] = "Bashkir";
	$enm['be'] = "Belarusian";
	$enm['bg'] = "Bulgarian";
	$enm['bh'] = "Bihari";
	$enm['bi'] = "Bislama";
	$enm['bn'] = "Bengali";
	$enm['bo'] = "Tibetan";
	$enm['br'] = "Breton";
	$enm['bs'] = "Bosnian";
	$enm['ca'] = "Catalan";
	$enm['ce'] = "Chechen";
	$enm['ch'] = "Chamorro";
	$enm['co'] = "Corsican";
	$enm['cs'] = "Czech";
	$enm['cu'] = "Church Slavic";
	$enm['cv'] = "Chuvash";
	$enm['cy'] = "Welsh";
	$enm['da'] = "Danish";
	$enm['de'] = "German";
	$enm['dz'] = "Dzongkha";
	$enm['el'] = "Greek";
	$enm['en'] = "English";
	$enm['eo'] = "Esperanto";
	$enm['es'] = "Spanish";
	$enm['et'] = "Estonian";
	$enm['eu'] = "Basque";
	$enm['fa'] = "Persian";
	$enm['fi'] = "Finnish";
	$enm['fj'] = "Fijian";
	$enm['fo'] = "Faeroese";
	$enm['fr'] = "French";
	$enm['fy'] = "Frisian";
	$enm['ga'] = "Irish";
	$enm['gd'] = "Gaelic (Scots)";
	$enm['gl'] = "Gallegan";
	$enm['gn'] = "Guarani";
	$enm['gu'] = "Gujarati";
	$enm['gv'] = "Manx";
	$enm['ha'] = "Hausa";
	$enm['he'] = "Hebrew";
	$enm['hi'] = "Hindi";
	$enm['ho'] = "Hiri Motu";
	$enm['hr'] = "Croatian";
	$enm['hu'] = "Hungarian";
	$enm['hy'] = "Armenian";
	$enm['hz'] = "Herero";
	$enm['ia'] = "Interlingua";
	$enm['id'] = "Indonesian";
	$enm['ie'] = "Interlingue";
	$enm['ik'] = "Inupiaq";
	$enm['is'] = "Icelandic";
	$enm['it'] = "Italian";
	$enm['iu'] = "Inuktitut";
	$enm['ja'] = "Japanese";
	$enm['jw'] = "Javanese";
	$enm['ka'] = "Georgian";
	$enm['ki'] = "Kikuyu";
	$enm['kj'] = "Kuanyama";
	$enm['kk'] = "Kazakh";
	$enm['kl'] = "Kalaallisut";
	$enm['km'] = "Khmer";
	$enm['kn'] = "Kannada";
	$enm['ko'] = "Korean";
	$enm['ks'] = "Kashmiri";
	$enm['ku'] = "Kurdish";
	$enm['kv'] = "Komi";
	$enm['kw'] = "Cornish";
	$enm['ky'] = "Kirghiz";
	$enm['la'] = "Latin";
	$enm['lb'] = "Letzeburgesch";
	$enm['ln'] = "Lingala";
	$enm['lo'] = "Lao";
	$enm['lt'] = "Lithuanian";
	$enm['lv'] = "Latvian";
	$enm['mg'] = "Malagasy";
	$enm['mh'] = "Marshall";
	$enm['mi'] = "Maori";
	$enm['mk'] = "Macedonian";
	$enm['ml'] = "Malayalam";
	$enm['mn'] = "Mongolian";
	$enm['mo'] = "Moldavian";
	$enm['mr'] = "Marathi";
	$enm['ms'] = "Malay";
	$enm['mt'] = "Maltese";
	$enm['my'] = "Burmese";
	$enm['na'] = "Nauru";
	$enm['nb'] = "Norwegian Bokmal";
	$enm['nd'] = "Ndebele, North";
	$enm['ne'] = "Nepali";
	$enm['ng'] = "Ndonga";
	$enm['nl'] = "Dutch";
	$enm['nn'] = "Norwegian Nynorsk";
	$enm['no'] = "Norwegian";
	$enm['nr'] = "Ndebele, South";
	$enm['nv'] = "Navajo";
	$enm['ny'] = "Chichewa; Nyanja";
	$enm['oc'] = "Occitan (post 1500)";
	$enm['om'] = "Oromo";
	$enm['or'] = "Oriya";
	$enm['os'] = "Ossetian; Ossetic";
	$enm['pa'] = "Panjabi";
	$enm['pi'] = "Pali";
	$enm['pl'] = "Polish";
	$enm['ps'] = "Pushto";
	$enm['pt'] = "Portuguese";
	$enm['pb'] = "Brazilian Portuguese";
	$enm['qu'] = "Quechua";
	$enm['rm'] = "Rhaeto-Romance";
	$enm['rn'] = "Rundi";
	$enm['ro'] = "Romanian";
	$enm['ru'] = "Russian";
	$enm['rw'] = "Kinyarwanda";
	$enm['sa'] = "Sanskrit";
	$enm['sc'] = "Sardinian";
	$enm['sd'] = "Sindhi";
	$enm['se'] = "Sami";
	$enm['sg'] = "Sango";
	$enm['si'] = "Sinhalese";
	$enm['sk'] = "Slovak";
	$enm['sl'] = "Slovenian";
	$enm['sm'] = "Samoan";
	$enm['sn'] = "Shona";
	$enm['so'] = "Somali";
	$enm['sq'] = "Albanian";
	$enm['sr'] = "Serbian";
	$enm['ss'] = "Swati";
	$enm['st'] = "Sotho";
	$enm['su'] = "Sundanese";
	$enm['sv'] = "Swedish";
	$enm['sw'] = "Swahili";
	$enm['ta'] = "Tamil";
	$enm['te'] = "Telugu";
	$enm['tg'] = "Tajik";
	$enm['th'] = "Thai";
	$enm['ti'] = "Tigrinya";
	$enm['tk'] = "Turkmen";
	$enm['tl'] = "Tagalog";
	$enm['tn'] = "Tswana";
	$enm['to'] = "Tonga";
	$enm['tr'] = "Turkish";
	$enm['ts'] = "Tsonga";
	$enm['tt'] = "Tatar";
	$enm['tw'] = "Twi";
	$enm['ug'] = "Uighur";
	$enm['uk'] = "Ukrainian";
	$enm['ur'] = "Urdu";
	$enm['uz'] = "Uzbek";
	$enm['vi'] = "Vietnamese";
	$enm['vo'] = "Volapuk";
	$enm['wo'] = "Wolof";
	$enm['xh'] = "Xhosa";
	$enm['yi'] = "Yiddish";
	$enm['yo'] = "Yoruba";
	$enm['za'] = "Zhuang";
	$enm['zh'] = "Chinese";
	$enm['zu'] = "Zulu";
	return $enm;
}

function qtranxf_language_predefined($lang)
{
	$language_names = qtranxf_default_language_name();
	return isset($language_names[$lang]);
}

function qtranxf_language_configured($prop,$opn=null)
{
	global $appypie_options;
	$val = call_user_func('qtranxf_default_'.$prop);
	if(!$opn){
		if(isset($appypie_options['languages'][$prop])){
			$opn = $appypie_options['languages'][$prop];
		}else{
			$opn = 'appypie_'.$prop;
		}
	}
	$opt = get_option($opn,array());
	if($opt){
		$val = array_merge($val,$opt);
	}
	return $val;
}

/**
 * Fill merged array of stored and pre-defined language properties
 */
function qtranxf_languages_configured(&$cfg)
{
	global $appypie_options;
	foreach($appypie_options['languages'] as $nm => $opn){
		$cfg[$nm] = qtranxf_language_configured($nm,$opn);
	}
	return $cfg;
}

/**
 * Load enabled languages properties from  database
 */
function qtranxf_load_languages_enabled()
{
	global $q_config, $appypie_options;
	foreach($appypie_options['languages'] as $nm => $opn){
		$f = 'qtranxf_default_'.$nm;
		qtranxf_load_option_func($nm,$opn,$f);
		$val = array();
		$def = null;
		foreach($q_config['enabled_languages'] as $lang){
			if(isset($q_config[$nm][$lang])){
				$val[$lang] = $q_config[$nm][$lang];
			}else{
				if(is_null($def) && function_exists($f)) $def = call_user_func($f);
				$val[$lang] = isset($def[$lang]) ? $def[$lang] : '';
			}
		}
		$q_config[$nm] = $val;
	}

}
