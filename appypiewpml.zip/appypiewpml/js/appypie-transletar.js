/* Auto Transletar script 2016 */
  $(document).ready(function(){ 
  	setTimeout(function(){ 
		var lang = document.location.href.split(".")[0].split("//")[1];
		if(lang == "zh")
         {
          lang = "zh-CN"
         }
		//alert(lang );
		jQuery(".goog-te-combo").val(lang);
		fireEvent(jQuery(".goog-te-combo")[0], "change")
		}, 1000);
  });
  // select value
  function fireEvent(el,e){
    if (document.createEventObject){
        //for IE
        var evt = document.createEventObject();
        return el.fireEvent('on'+e,evt)
    }
    else{
        // For other browsers
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent(e, true, true ); 
        return !el.dispatchEvent(evt);
    }
}