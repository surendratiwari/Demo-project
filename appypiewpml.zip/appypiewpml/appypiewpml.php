<?php
/**
Plugin Name: Appypiewpml New
Plugin URI: http://appypie.com/
Description: Adds user-friendly and database-friendly multilingual content support.
Author: appypie Team
Author URI: http://appypie.com/about-us
Tags: multilingual, multi, language, admin, tinymce, widget, switcher, professional, human, translation, service, appypie,  appypie WPML
Text Domain: appypie
Domain Path: /lang/
*/

/*
	Copyright 2016  appypie Team 
	All Supporters! Thanks for all the gifts, cards and donations!
*/

if ( ! function_exists( 'add_filter' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}

//define('QTX_VERSION','');

if ( ! defined( 'appypie_FILE' ) ) {
	define( 'appypie_FILE', __FILE__ );
	define( 'appypie_DIR', dirname(__FILE__) );
}

require_once(appypie_DIR.'/inc/appypie_class_translator.php');

if(is_admin() ){ // && !(defined('DOING_AJAX') && DOING_AJAX) //todo cleanup
	require_once(appypie_DIR.'/admin/appypie_activation_hook.php');
	qtranxf_register_activation_hooks();
}

